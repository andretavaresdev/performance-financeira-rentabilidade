# Base de dados — Performance Financeira e Rentabilidade

Dados sintéticos e reproduzíveis para projeto de portfólio em Power BI.

## Características

- Período: janeiro/2024 a setembro/2026
- 8 unidades de negócio
- 4 regiões
- 5 categorias
- 30 produtos
- Seed de geração: 20261002

## Modelagem proposta

- DimCalendario
- DimCategoria
- DimProduto
- DimUnidade
- FatoRealizadoFinanceiro
- FatoOrcamento

### Granularidade

- FatoRealizadoFinanceiro: mês x unidade x produto
- FatoOrcamento: mês x unidade x categoria

O orçamento foi mantido em granularidade diferente do realizado de forma intencional,
simulando um cenário empresarial em que o planejamento financeiro é realizado em um
nível mais agregado.

## Observação

Os dados são totalmente sintéticos e não representam informações de uma empresa real.
Foram estruturados para conter padrões coerentes de receita, custos, margem,
sazonalidade e desvios entre realizado e orçamento, permitindo análise financeira gerencial.


## Formato regional

Os arquivos CSV seguem o padrão Português (Brasil):

- separador de campos: ponto e vírgula (`;`)
- separador decimal: vírgula (`,`)
- datas: ano-mês-dia nos arquivos de origem para importação consistente

No Power BI, ao alterar tipos no Power Query, utilize a localidade **Português (Brasil)** quando necessário.
